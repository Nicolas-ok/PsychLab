# PsychLab Skill

Upload this folder or the ZIP to ChatGPT via Plugins → Skills → Create → Upload from your computer.

The skill is defined by `SKILL.md`. Supporting material lives in `references/`.
